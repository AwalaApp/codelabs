# Android-powered, Awala Ping example

This is the final implementation of the [codelab for the Android app in a centralised service](https://codelabs.awala.network/codelabs/android-centralised/).
