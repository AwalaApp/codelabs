# Template for the Node.js public endpoint codelab

This is the accompanying code template for the [Node.js public endpoint codelab](https://codelabs.awala.network/codelabs/nodejs-pong/).
