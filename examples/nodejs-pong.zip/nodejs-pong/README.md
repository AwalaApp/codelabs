# Node.js-powered, public endpoint for the Awala Ping service

This is the resulting app from the [Node.js public endpoint codelab](https://codelabs.awala.network/codelabs/nodejs-pong/).
